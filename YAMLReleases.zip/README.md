# Introduction

Demo project for Introduction to CI/CD talk at Microsoft User Group Hyderabad

# Getting Started

This is a .NET Single Page Application using React. If yiou want to learn more about the template and how it works [check out this video](https://www.youtube.com/watch?v=mILRINbRiJM).

# Build and Test

To build and run this application locally

1. Pull down the source
2. Compile and Run

Also check out my [YouTube Playlist](https://www.youtube.com/playlist?list=PL59L9XrzUa-m7AFDgjWuwm6exyCklc03U) on different build/deploy scenarios.
